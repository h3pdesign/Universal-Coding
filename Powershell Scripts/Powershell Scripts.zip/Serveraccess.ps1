﻿# Remote Script execution

$Server = C:\Temp\ServerList.txt

Invoke-Command -ComputerName   gll-h2-fs61 # $Server 
                -ScriptBlock { .\Get-Longpaths.ps1 } 
                -credential nds.pedersen